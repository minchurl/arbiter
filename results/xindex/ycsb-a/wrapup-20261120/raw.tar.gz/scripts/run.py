"""Full YCSB-A; three cyclic orders; direct GNU-time peak RSS, no in-loop observer."""
import csv,hashlib,json,os,re,signal,subprocess,time
from pathlib import Path
from host_guard import snapshot,foreign,wait_quiet,POLICY
root=Path.cwd();base=root/'build/xindex-ycsb-a-wrapup';out=base/'runs';out.mkdir(exist_ok=False);rows=[];waits=[]
bins={mode:base/'candidate/xindex'/('ycsb_bench-native' if mode=='native' else 'ycsb_bench-arbiter') for mode in ('native','local','cxl')};hashes={k:hashlib.sha256(p.read_bytes()).hexdigest() for k,p in bins.items()}
orders=[['native','local','cxl'],['local','cxl','native'],['cxl','native','local']]
(out/'manifest.json').write_text(json.dumps(dict(orders=orders,hashes=hashes,guard=POLICY,workload='Unchanged YCSB-A: 100M load, complete 400M transactions, 31 foreground + 1 background',policy='evidence-balanced-size-tiebreaker.config; automatic seed selection; no companion/adaptive/partial placement',memory='GNU time %M: whole-process peak RSS in KiB. Runtime residency: selected private heap pages, not whole-process RSS. No smaps walk or debugger in throughput runs.',main_base='21498d914c5f302cb1e80d8a03315421c2c52714'),indent=2)+'\n')
for repeat,order in enumerate(orders,1):
 for mode in order:
  for attempt in range(1,5):
   wait_quiet(waits);stem=out/f'{repeat}-{mode}-attempt{attempt}';binary=bins[mode];assert hashlib.sha256(binary.read_bytes()).hexdigest()==hashes[mode];node=2 if mode=='cxl' else 0
   env={k:v for k,v in os.environ.items() if not k.startswith(('ARBITER_','XINDEX_','MALLOC_CONF'))};env.update(ARBITER_TARGET_NODE=str(node),ARBITER_ARENA_REPORT='1',XINDEX_VALIDATE='1',LD_LIBRARY_PATH='/opt/intel/oneapi/mkl/latest/lib')
   command=['systemd-run','--user','--scope','--quiet','-p','MemoryMax=64G','-p','MemorySwapMax=0','--','/usr/bin/time','-f','%M %W %e','-o',str(stem.with_suffix('.time')),'timeout','--kill-after=10','900','numactl','--cpunodebind=0','--membind=0',str(binary),'--fg','31','--bg','1','--iteration','1','--ycsb_type','a','--ycsb-load',str(root/'benchmark/xindex/YCSB/xindex_dat/xindex_load_ycsb_a.dat'),'--ycsb-tx',str(root/'benchmark/xindex/YCSB/xindex_dat/xindex_transaction_ycsb_a.dat')]
   stem.with_suffix('.command.json').write_text(json.dumps(dict(command=command,environment={k:v for k,v in env.items() if k.startswith(('ARBITER_','XINDEX_','LD_LIBRARY'))}),indent=2)+'\n')
   before=snapshot();busy=[]
   with stem.with_suffix('.log').open('w') as f:
    process=subprocess.Popen(command,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
    try:
     while process.poll() is None:
      time.sleep(.5);after=snapshot();busy+=foreign(before,after,process.pid);before=after
    finally:
     if process.poll() is None:os.killpg(process.pid,signal.SIGTERM);process.wait(timeout=15)
   stem.with_suffix('.host.json').write_text(json.dumps(dict(foreign_cpu=busy),indent=2)+'\n');(out/'host-waits.json').write_text(json.dumps(waits,indent=2)+'\n');text=stem.with_suffix('.log').read_text();assert process.returncode==0,(stem,text[-2000:])
   assert all(s in text for s in ('load number : 100000000','executed=400000000','sampled_keys=4096 successful_reads=4096 failed_reads=0 digest=0x7474b8e9d3962859'))
   for op,count in [('read',199993860),('update',200006140),('insert',0),('rmw',0),('remove',0)]:assert re.search(r'^\s*'+op+': '+str(count)+'$',text,re.M)
   assert 'arbiter-allocation-failure' not in text
   fields=lambda line:{k:int(v) for k,v in re.findall(r'(\w+)=(-?\d+)',line)}
   res={};sites=[]
   if mode!='native':
    sites=[fields(s) for s in text.splitlines() if s.startswith('arbiter-arena-site ')]
    assert [(s['site'],s['allocations'],s['frees']) for s in sites]==[(68,26395417,0),(71,26395622,0),(74,143,0)]
    res=fields(next(s for s in text.splitlines() if s.startswith('arbiter-arena-residency ')))
    assert res['resident_pages']==res.get(f'node{node}_pages')==5000778 and res['query_error_pages']==res['mincore_error_batches']==0
    assert 'fallback_allocations=0' in text
   else:assert 'arbiter-arena-site ' not in text
   rss,swaps,wall=stem.with_suffix('.time').read_text().split();assert int(swaps)==0
   if busy:print('REJECT foreign CPU overlap',repeat,mode,attempt,flush=True);continue
   seconds=float(re.search(r'Time\(sec\) : ([\d.]+)',text)[1]);row=dict(round=repeat,mode=mode,order_position=order.index(mode)+1,attempt=attempt,ops=400000000,seconds=seconds,mtx_s=400/seconds,peak_rss_kib=int(rss),wall_seconds=float(wall),selected_resident_bytes=res.get('resident_bytes',0),selected_node0_pages=res.get('node0_pages',0),selected_node2_pages=res.get('node2_pages',0),selected_allocations=sum(s['allocations'] for s in sites),sampled_digest='0x7474b8e9d3962859',valid=True);rows.append(row)
   with (out/'runs.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=row,lineterminator='\n');w.writeheader();w.writerows(rows)
   print('ROUND',repeat,mode,round(row['mtx_s'],3),'Mtx/s; peak RSS',round(int(rss)/1024**2,3),'GiB',flush=True);break
  else:raise RuntimeError('Repeated host interference')
print('ALL 9 RUNS FINISHED',flush=True)
