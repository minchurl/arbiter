import csv,hashlib,json,os,re,resource,shlex,subprocess
from pathlib import Path
resource.setrlimit(resource.RLIMIT_CORE,(0,0));root=Path.cwd();base=root/'build/xindex-ycsb-a-wrapup';old=base/'baseline';new=base/'candidate';checks=[]
env={**os.environ,**json.loads((new/'environment.json').read_text())};opt=env['OPT'];plugins=[x/'compiler/lib/ArbiterLLVMPlugin.so' for x in [old,new]]
for name in ['ycsb_bench.bc','ycsb_bench.arbiter.bc','ycsb_bench.hitm-seed-sites.csv','ycsb_bench-native','ycsb_bench-arbiter']:
 a=(old/'xindex'/name).read_bytes();b=(new/'xindex'/name).read_bytes();assert a==b,name
 checks.append(dict(check=name,identical=True,sha256=hashlib.sha256(a).hexdigest()))
selected=[int(r['site_id']) for r in csv.DictReader((new/'xindex/ycsb_bench.hitm-seed-sites.csv').open()) if r['selected']=='yes'];assert selected==[68,71,74,90,97,98,99,100]
for file in sorted((root/'tests/llvm').glob('hitm-seed-*.ll')):
 for line in file.read_text().splitlines():
  if not line.startswith('; RUN: '):continue
  command=line[7:].split('|')[0];negative=command.startswith('not ')
  if negative:command=command[4:]
  command=command.replace('2>&1','').replace('opt ',opt+' ',1);outputs=[]
  for plugin in plugins:
   args=shlex.split(command.replace('%shlibdir/ArbiterLLVMPlugin%shlibext',str(plugin)).replace('%s',str(file)));r=subprocess.run(args,env=env,capture_output=True,text=True);assert (r.returncode!=0)==negative,(args,r.stderr)
   output=r.stdout if not negative else next(s for s in r.stderr.splitlines() if 'LLVM ERROR:' in s);outputs.append(output)
  assert outputs[0]==outputs[1],line
  checks.append(dict(check=file.name,command=line[7:],baseline_equals_candidate=True,expected_failure=negative))
r=subprocess.run([opt,'-load-pass-plugin',str(plugins[1]),'-passes=arbiter-report-hitm-seed-sites','-arbiter-hitm-weight-published-rmw=3','-disable-output',str(new/'xindex/ycsb_bench.bc')],env=env,text=True,capture_output=True)
assert r.returncode!=0 and 'Unknown command line argument' in r.stderr
checks.append(dict(check='removed option is rejected',passed=True))
env.update(ARBITER_TARGET_NODE='0',CLANG=str(root/'.tools/llvm-18.1.8/bin/clang'),LLVM_DIS=str(root/'.tools/llvm18-apt-root/usr/bin/llvm-dis-18'))
r=subprocess.run(['bash','scripts/smoke.sh'],env=env,text=True,capture_output=True);checks.append(dict(check='existing compiler/runtime smoke',returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));assert r.returncode==0,r.stderr
(base/'checks.json').write_text(json.dumps(dict(selected_sites=selected,checks=checks),indent=2)+'\n');print('PASS native and rewritten IR, seed report, and both executables byte-identical; existing fixture invocations and smoke passed')
