"""Read process memory outside timing, with all inferior threads stopped."""
import gdb,json,os,re
from pathlib import Path
out=Path(os.environ['ARBITER_RSS_DIAGNOSTIC_DIR']);records=[]
class Snapshot(gdb.Breakpoint):
 def __init__(self,line,phase):
  super().__init__('ycsb_bench.cpp:'+str(line),internal=False);self.phase=phase
 def stop(self):
  pid=gdb.selected_inferior().pid;proc=Path('/proc')/str(pid)
  for name in ['smaps_rollup','numa_maps','status']:(out/(self.phase+'.'+name)).write_text((proc/name).read_text())
  smaps={k:int(v) for k,v in re.findall(r'^(\w+):\s+(\d+) kB$',(out/(self.phase+'.smaps_rollup')).read_text(),re.M)}
  assert smaps['Swap']==0
  nodes={}
  for line in (out/(self.phase+'.numa_maps')).read_text().splitlines():
   fields=dict(re.findall(r'\b(N\d+|kernelpagesize_kB)=(\d+)',line));size=int(fields.get('kernelpagesize_kB',4));assert size==4
   for key,value in fields.items():
    if key.startswith('N'):nodes[key]=nodes.get(key,0)+int(value)*size
  status={k:int(v) for k,v in re.findall(r'^(VmRSS|VmHWM|VmSwap):\s+(\d+) kB$',(out/(self.phase+'.status')).read_text(),re.M)}
  group=next(line.split(':',2)[2] for line in (proc/'cgroup').read_text().splitlines() if line.startswith('0::'));cg=Path('/sys/fs/cgroup')/group.lstrip('/');limits={name:(cg/name).read_text().strip() for name in ['memory.max','memory.swap.max','memory.events']}
  assert limits['memory.max']=='68719476736' and limits['memory.swap.max']=='0'
  records.append(dict(phase=self.phase,pid=pid,status_kib=status,cgroup=group,cgroup_limits=limits,pc=str(gdb.selected_frame().pc()),source_line=gdb.selected_frame().find_sal().line,smaps_kib=smaps,numa_resident_kib=nodes))
  (out/'snapshots.json').write_text(json.dumps(records,indent=2)+'\n');self.enabled=False
  print('RSS SNAPSHOT',self.phase,smaps['Rss'],'KiB',flush=True)
  return False
gdb.execute('set pagination off');gdb.execute('set confirm off');gdb.execute('set print thread-events off');gdb.execute('set disable-randomization off')
Snapshot(606,'before-replay');Snapshot(686,'after-replay');gdb.execute('run')
assert len(records)==2 and [r['phase'] for r in records]==['before-replay','after-replay']
