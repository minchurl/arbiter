"""Separate diagnostics; never use debugger-run throughput as performance data."""
import json,os,subprocess
from pathlib import Path
from host_guard import wait_quiet
root=Path.cwd();base=root/'build/xindex-ycsb-a-wrapup';assert 'ALL 9 RUNS FINISHED' in (base/'final.console').read_text();records=[]
for mode in ('native','local','cxl'):
 out=base/'rss'/mode;out.mkdir(parents=True,exist_ok=False);wait_quiet([])
 binary=base/'candidate/xindex'/('ycsb_bench-native' if mode=='native' else 'ycsb_bench-arbiter');node=2 if mode=='cxl' else 0
 env={k:v for k,v in os.environ.items() if not k.startswith(('ARBITER_','XINDEX_','MALLOC_CONF'))};env.update(ARBITER_TARGET_NODE=str(node),ARBITER_ARENA_REPORT='1',XINDEX_VALIDATE='1',LD_LIBRARY_PATH='/opt/intel/oneapi/mkl/latest/lib',ARBITER_RSS_DIAGNOSTIC_DIR=str(out))
 cmd=['systemd-run','--user','--scope','--quiet','-p','MemoryMax=64G','-p','MemorySwapMax=0','--','timeout','--kill-after=10','900','numactl','--cpunodebind=0','--membind=0','gdb','-q','-nx','--batch','-ex','source '+str(base/'scripts/rss-gdb.py'),'--args',str(binary),'--fg','31','--bg','1','--iteration','1','--ycsb_type','a','--ycsb-load',str(root/'benchmark/xindex/YCSB/xindex_dat/xindex_load_ycsb_a.dat'),'--ycsb-tx',str(root/'benchmark/xindex/YCSB/xindex_dat/xindex_transaction_ycsb_a.dat')]
 (out/'command.json').write_text(json.dumps(dict(command=cmd,environment={k:v for k,v in env.items() if k.startswith(('ARBITER_','XINDEX_','LD_LIBRARY'))}),indent=2)+'\n')
 with (out/'console.log').open('w') as f:r=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 text=(out/'console.log').read_text();assert r.returncode==0 and 'exited normally' in text and 'executed=400000000' in text and 'digest=0x7474b8e9d3962859' in text,(mode,text[-3000:])
 snapshots=json.loads((out/'snapshots.json').read_text());assert len(snapshots)==2
 records.extend(dict(mode=mode,**s) for s in snapshots);print('RSS VERIFIED',mode,[(s['phase'],round(s['smaps_kib']['Rss']/1024**2,3)) for s in snapshots],flush=True)
(base/'rss/summary.json').write_text(json.dumps(records,indent=2)+'\n');print('RSS DIAGNOSTICS FINISHED',flush=True)
