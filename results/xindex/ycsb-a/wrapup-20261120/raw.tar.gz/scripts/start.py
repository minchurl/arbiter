import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();base=root/'build/xindex-ycsb-a-wrapup';env={**os.environ,**json.loads((base/'candidate/environment.json').read_text())};records=[]
for cmd in [['cmake','--build',str(base/'candidate/compiler'),'-j','4'],['bash','scripts/build-xindex-llvm.sh'],[sys.executable,str(base/'scripts/check.py')]]:
 r=subprocess.run(cmd,env=env,text=True,capture_output=True);records.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(base/'final-build-checks.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,r.stderr;print(r.stdout[-1200:],flush=True)
traces={};previous=json.loads((base/'expected-traces.json').read_text())
for name,old in previous.items():
 p=root/name;h=hashlib.sha256()
 with p.open('rb') as f:
  while chunk:=f.read(8*1024**2):h.update(chunk)
 assert h.hexdigest()==old['sha256'];traces[name]=dict(sha256=h.hexdigest(),bytes=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns);print('TRACE VERIFIED',p.name,flush=True)
(base/'trace-hashes.json').write_text(json.dumps(traces,indent=2)+'\n')
host={}
for cmd in [['uname','-a'],['lscpu'],['numactl','--hardware'],['ldd',str(base/'candidate/xindex/ycsb_bench-arbiter')]]:
 r=subprocess.run(cmd,text=True,capture_output=True);host[' '.join(cmd)]=dict(returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
(base/'host.json').write_text(json.dumps(host,indent=2)+'\n')
subprocess.run([sys.executable,str(base/'scripts/run.py')],check=True)
