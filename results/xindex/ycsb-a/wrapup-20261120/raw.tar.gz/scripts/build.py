import hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path.cwd();base=root/'build/xindex-ycsb-a-wrapup';stage=sys.argv[1];out=base/stage;out.mkdir(exist_ok=False)
tool=json.loads((base/'toolchain.json').read_text());env={k:v for k,v in os.environ.items() if not k.startswith(('ARBITER_','XINDEX_'))};env.update(tool['environment']);build=out/'compiler';records=[]
def run(command,label):
 r=subprocess.run(list(map(str,command)),env=env,text=True,capture_output=True);records.append(dict(label=label,command=list(map(str,command)),returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');assert r.returncode==0,(label,r.stderr[-3000:]);print(stage,label,'PASS',flush=True)
run(['cmake','-S',root,'-B',build,'-G','Ninja',*['-D'+k+'='+v for k,v in tool['successful_cache_options'].items() if k!='CMAKE_GENERATOR']],'configure')
run(['cmake','--build',build,'-j','4'],'build')
env.update(CLANGXX=str(root/'.tools/llvm-18.1.8/bin/clang++'),OPT=str(root/'.tools/llvm18-apt-root/usr/bin/opt-18'),ARBITER_BUILD_DIR=str(build),ARBITER_BENCH_BUILD_DIR=str(out/'xindex'),ARBITER_BUILD_XINDEX_NATIVE='1',ARBITER_HITM_SEED_CONFIG=str(root/'configs/hitm-seed/policy-candidates/evidence-balanced-size-tiebreaker.config'))
run(['bash','scripts/build-xindex-llvm.sh'],'xindex-source-build')
(out/'environment.json').write_text(json.dumps({k:v for k,v in env.items() if k.startswith(('ARBITER_','CLANGXX','OPT','LD_LIBRARY','LIBRARY_PATH','CPLUS'))},indent=2)+'\n')
paths=subprocess.check_output(['git','ls-files','--','CMakeLists.txt','compiler/','runtime/','benchmark/xindex/','scripts/','configs/'],text=True).splitlines();files={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths if (root/p).is_file() and (root/p).stat().st_size<20000000}
for p in (out/'xindex').iterdir():
 if p.is_file():files[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'hashes.json').write_text(json.dumps(files,indent=2)+'\n')
print('BUILD FINISHED',stage,flush=True)
