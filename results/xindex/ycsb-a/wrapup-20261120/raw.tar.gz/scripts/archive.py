"""Retain concise tables plus a lossless archive of commands, logs and snapshots."""
import csv,gzip,hashlib,io,json,shutil,subprocess,tarfile
from pathlib import Path
root=Path.cwd();b=root/'build/xindex-ycsb-a-wrapup';out=root/'results/xindex/ycsb-a/wrapup-20261120';out.mkdir(exist_ok=False)
rows=list(csv.DictReader((b/'final-runs/runs.csv').open()));assert len(rows)==9 and all(r['valid']=='True' for r in rows)
assert 'ALL 9 RUNS FINISHED' in (b/'final.console').read_text() and 'RSS DIAGNOSTICS FINISHED' in (b/'rss.console').read_text()
assert not subprocess.check_output(['git','diff','main','--','benchmark/','runtime/'])
main=subprocess.check_output(['git','rev-parse','main'],text=True).strip();assert main=='21498d914c5f302cb1e80d8a03315421c2c52714'
for key,value in json.loads((b/'baseline/hashes.json').read_text()).items():
 if key.startswith(('benchmark/xindex/','runtime/')):assert hashlib.sha256((root/key).read_bytes()).hexdigest()==value,key
for name,record in json.loads((b/'trace-hashes.json').read_text()).items():
 stat=(root/name).stat();assert stat.st_size==record['bytes'] and stat.st_mtime_ns==record['mtime_ns']
for row in rows:
 stem=b/'final-runs'/f"{row['round']}-{row['mode']}-attempt{row['attempt']}";assert not json.loads(stem.with_suffix('.host.json').read_text())['foreign_cpu']
 assert 'digest='+row['sampled_digest'] in stem.with_suffix('.log').read_text()
 assert int(stem.with_suffix('.time').read_text().split()[0])==int(row['peak_rss_kib'])
snapshots=json.loads((b/'rss/summary.json').read_text());assert len(snapshots)==6 and all(s['smaps_kib']['Swap']==0 for s in snapshots)
memory=[]
for s in snapshots:memory.append(dict(mode=s['mode'],phase=s['phase'],rss_gib=s['smaps_kib']['Rss']/1024**2,pss_gib=s['smaps_kib']['Pss']/1024**2,numa_node0_gib=s['numa_resident_kib'].get('N0',0)/1024**2,numa_node1_gib=s['numa_resident_kib'].get('N1',0)/1024**2,numa_node2_gib=s['numa_resident_kib'].get('N2',0)/1024**2,swap_kib=s['smaps_kib']['Swap']))
with (out/'rss-snapshots.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=memory[0],lineterminator='\n');w.writeheader();w.writerows(memory)
for name in ['summary.csv','comparisons.csv']:shutil.copyfile(b/name,out/name)
shutil.copyfile(b/'final-runs/runs.csv',out/'runs.csv');shutil.copyfile(b/'scripts/summarize.py',out/'summarize.py')
selected=[r for r in csv.DictReader((b/'candidate/xindex/ycsb_bench.hitm-seed-sites.csv').open()) if r['selected']=='yes']
with (out/'selected-sites.csv').open('w') as f:w=csv.DictWriter(f,fieldnames=selected[0],lineterminator='\n');w.writeheader();w.writerows(selected)
checks=json.loads((b/'checks.json').read_text());manifest=json.loads((b/'final-runs/manifest.json').read_text());manifest.update(main_base=main,selected_site_ids=checks['selected_sites'],checks='Native IR, rewritten IR, complete seed report, native executable and Arbiter executable are byte-identical before/after cleanup. 14 retained fixture commands match baseline; existing compiler/runtime smoke passed; removed option rejected.',completed_runs=9,retained_attempts=len(list((b/'final-runs').glob('*.log'))),preliminary_attempts=len(list((b/'runs').glob('*.log'))),preliminary_results_in_summary=False,guard_correction='Initial whole-scan timestamps and zero tick tolerance rejected one-core accounting jitter. Final suite uses per-process sample times plus two ticks of accounting tolerance; all earlier processes excluded.',rss_diagnostics=3,rss_diagnostics_in_throughput=False,source_edits='Removed one micro-specific published-RMW scoring parameter and analysis; no benchmark or runtime source edits.',swap_evidence='All processes run with MemorySwapMax=0; all six smaps snapshots show Swap=0. GNU time %W is recorded but is not independent swap evidence on Linux.',limitations='Three full runs per mode on one monitored shared host. Whole-process peak RSS includes setup/validation, not only timed replay. Diagnostic snapshots are separate processes, not peak-RSS measurements. No historical throughput pooling.')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
tracked=subprocess.check_output(['git','ls-files','--','compiler/','runtime/','benchmark/xindex/','scripts/','configs/'],text=True).splitlines();hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in tracked if (root/p).is_file() and (root/p).stat().st_size<20000000};(b/'final-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
(b/'code.patch').write_bytes(subprocess.check_output(['git','diff','main','--','compiler/','configs/','scripts/','tests/']))
raw=[p for p in b.iterdir() if p.is_file() and p.suffix in ('.json','.csv','.console','.patch')]
for folder in ['scripts','runs','final-runs','rss']:raw.extend(p for p in (b/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for stage in ['baseline','candidate']:
 raw.extend((b/stage).glob('*.json'));raw.extend((b/stage/'xindex').glob('*.csv'));raw.extend((b/stage/'xindex').glob('*.opt-args'))
with (out/'raw.tar.gz').open('wb') as file:
 with gzip.GzipFile(filename='',mode='wb',fileobj=file,mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as archive:
   for p in sorted(raw):
    data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(b)));info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(out/'raw.tar.gz','r:gz') as archive:
 for m in archive.getmembers():assert archive.extractfile(m).read()==(b/m.name).read_bytes()
(out/'checksums.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file()))
print('ARCHIVE VERIFIED:',out,'raw files:',len(raw))
