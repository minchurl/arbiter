import subprocess,sys,time
from pathlib import Path
b=Path('build/xindex-ycsb-a-wrapup')
while 'ALL 9 RUNS FINISHED' not in (b/'final.console').read_text():
 assert 'Traceback' not in (b/'final.console').read_text();time.sleep(2)
subprocess.run([sys.executable,str(b/'scripts/summarize.py')],check=True)
with (b/'rss.console').open('w') as f:subprocess.run([sys.executable,str(b/'scripts/rss.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
print('POST-MEASUREMENT CHECKS FINISHED',flush=True)
